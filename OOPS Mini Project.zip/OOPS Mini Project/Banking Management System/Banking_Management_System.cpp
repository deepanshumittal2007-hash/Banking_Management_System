
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Account {
protected:
    int accountNumber;
    string name;
    double balance;

public:
    Account(int accNo, string n, double b) {
        accountNumber = accNo;
        name = n;
        balance = b;
    }

    virtual ~Account() {}

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Money deposited successfully!\n";
        } else {
            cout << "Invalid deposit amount!\n";
        }
    }

    virtual void withdraw(double amount) = 0;
    virtual string getType() = 0;

    virtual void display() {
        cout << "\nAccount Number: " << accountNumber;
        cout << "\nAccount Holder: " << name;
        cout << "\nAccount Type: " << getType();
        cout << "\nBalance: " << balance << endl;
    }

    int getAccountNumber() {
        return accountNumber;
    }

    string getName() {
        return name;
    }

    double getBalance() {
        return balance;
    }
};

class SavingsAccount : public Account {
public:
    SavingsAccount(int accNo, string n, double b)
        : Account(accNo, n, b) {}

    string getType() {
        return "Savings";
    }

    void withdraw(double amount) {
        if (amount <= 0) {
            cout << "Invalid withdrawal amount!\n";
        } else if (amount > balance) {
            cout << "Insufficient balance!\n";
        } else {
            balance -= amount;
            cout << "Withdrawal successful!\n";
        }
    }
};

class CurrentAccount : public Account {
public:
    CurrentAccount(int accNo, string n, double b)
        : Account(accNo, n, b) {}

    string getType() {
        return "Current";
    }

    void withdraw(double amount) {
        if (amount <= 0) {
            cout << "Invalid withdrawal amount!\n";
        } else if (amount > balance) {
            cout << "Insufficient balance!\n";
        } else {
            balance -= amount;
            cout << "Withdrawal successful!\n";
        }
    }
};

class Bank {
private:
    Account* accounts[100];
    int count;
    int nextAccountNumber;

public:
    Bank() {
        count = 0;
        nextAccountNumber = 1001;

        for (int i = 0; i < 100; i++) {
            accounts[i] = NULL;
        }

        loadAccounts();
    }

    ~Bank() {
        saveAccounts();

        for (int i = 0; i < count; i++) {
            delete accounts[i];
        }
    }

    
    int findAccount(int accNo) {
        for (int i = 0; i < count; i++) {
            if (accounts[i]->getAccountNumber() == accNo) {
                return i;
            }
        }

        return -1;
    }

    void createAccount() {
        if (count >= 100) {
            cout << "Account limit reached!\n";
            return;
        }

        int choice;
        string name;
        double amount;

        cout << "\n1. Savings Account";
        cout << "\n2. Current Account";
        cout << "\nChoose account type: ";

        if (!(cin >> choice)) {
            cout << "Invalid account type!\n";
            cin.clear();
            cin.ignore(10000, '\n');
            return;
        }

        if (choice != 1 && choice != 2) {
            cout << "Invalid account type!\n";
            return;
        }

        cout << "Enter account holder name: ";
        cin >> ws;
        getline(cin, name);

        if (name.empty() ||
            name.find('|') != string::npos) {
            cout << "Invalid name!\n";
            return;
        }

        cout << "Enter opening balance: ";

        if (!(cin >> amount)) {
            cout << "Invalid amount!\n";
            cin.clear();
            cin.ignore(10000, '\n');
            return;
        }

        if (amount < 0) {
            cout << "Balance cannot be negative!\n";
            return;
        }

        int accNo = nextAccountNumber;

        if (choice == 1) {
            accounts[count] =
                new SavingsAccount(accNo, name, amount);
        } else {
            accounts[count] =
                new CurrentAccount(accNo, name, amount);
        }

        count++;
        nextAccountNumber++;

        cout << "\nAccount created successfully!";
        cout << "\nYour account number: " << accNo << endl;

        saveTransaction(accNo, "OPENING", amount);
        saveAccounts();
    }

    void depositMoney() {
        int accNo;
        double amount;

        cout << "Enter account number: ";

        if (!(cin >> accNo)) {
            cout << "Invalid account number!\n";
            cin.clear();
            cin.ignore(10000, '\n');
            return;
        }

        int index = findAccount(accNo);

        if (index == -1) {
            cout << "Account not found!\n";
            return;
        }

        cout << "Enter amount to deposit: ";

        if (!(cin >> amount)) {
            cout << "Invalid amount!\n";
            cin.clear();
            cin.ignore(10000, '\n');
            return;
        }

        if (amount <= 0) {
            cout << "Amount must be positive!\n";
            return;
        }

        accounts[index]->deposit(amount);

        saveTransaction(accNo, "DEPOSIT", amount);
        saveAccounts();

        cout << "Updated balance: "
             << accounts[index]->getBalance() << endl;
    }

    void withdrawMoney() {
        int accNo;
        double amount;

        cout << "Enter account number: ";

        if (!(cin >> accNo)) {
            cout << "Invalid account number!\n";
            cin.clear();
            cin.ignore(10000, '\n');
            return;
        }

        int index = findAccount(accNo);

        if (index == -1) {
            cout << "Account not found!\n";
            return;
        }

        cout << "Enter withdrawal amount: ";

        if (!(cin >> amount)) {
            cout << "Invalid amount!\n";
            cin.clear();
            cin.ignore(10000, '\n');
            return;
        }

        if (amount <= 0) {
            cout << "Amount must be positive!\n";
            return;
        }

        double oldBalance = accounts[index]->getBalance();

        accounts[index]->withdraw(amount);

        if (accounts[index]->getBalance() < oldBalance) {
            saveTransaction(accNo, "WITHDRAW", amount);
            saveAccounts();

            cout << "Remaining balance: "
                 << accounts[index]->getBalance() << endl;
        }
    }

    void displayAccount() {
        int accNo;

        cout << "Enter account number: ";

        if (!(cin >> accNo)) {
            cout << "Invalid account number!\n";
            cin.clear();
            cin.ignore(10000, '\n');
            return;
        }

        int index = findAccount(accNo);

        if (index == -1) {
            cout << "Account not found!\n";
            return;
        }

        accounts[index]->display();
    }

    void displayAllAccounts() {
        if (count == 0) {
            cout << "No accounts available!\n";
            return;
        }

        for (int i = 0; i < count; i++) {
            cout << "\n--------------------\n";
            accounts[i]->display();
        }
    }

    void saveAccounts() {
        ofstream file("accounts.txt");

        if (!file) {
            cout << "Error saving account records!\n";
            return;
        }

        for (int i = 0; i < count; i++) {
            file << accounts[i]->getType() << "|"
                 << accounts[i]->getAccountNumber() << "|"
                 << accounts[i]->getName() << "|"
                 << accounts[i]->getBalance() << "\n";
        }

        file.close();
    }

    void loadAccounts() {
        ifstream file("accounts.txt");

        if (!file) {
            return;
        }

        string type, accText, name, balanceText;

        while (count < 100 &&
               getline(file, type, '|') &&
               getline(file, accText, '|') &&
               getline(file, name, '|') &&
               getline(file, balanceText)) {

            int accNo = 0;
            double amount = 0;
            bool valid = true;

            if (accText.empty() || balanceText.empty()) {
                continue;
            }

            
            for (int j = 0; j < (int)accText.length(); j++) {
                if (accText[j] < '0' || accText[j] > '9') {
                    valid = false;
                    break;
                }

                accNo = accNo * 10 + (accText[j] - '0');
            }

            
            bool decimalSeen = false;
            double place = 0.1;

            for (int j = 0; j < (int)balanceText.length(); j++) {
                char c = balanceText[j];

                if (c == '.' && !decimalSeen) {
                    decimalSeen = true;
                } else if (c >= '0' && c <= '9') {
                    if (!decimalSeen) {
                        amount = amount * 10 + (c - '0');
                    } else {
                        amount += (c - '0') * place;
                        place /= 10;
                    }
                } else {
                    valid = false;
                    break;
                }
            }

            if (!valid || accNo <= 0 || amount < 0) {
                continue;
            }

            
            bool duplicate = false;

            for (int i = 0; i < count; i++) {
                if (accounts[i]->getAccountNumber() == accNo) {
                    duplicate = true;
                    break;
                }
            }

            if (duplicate) {
                continue;
            }

            if (type == "Savings") {
                accounts[count] =
                    new SavingsAccount(accNo, name, amount);
            } else if (type == "Current") {
                accounts[count] =
                    new CurrentAccount(accNo, name, amount);
            } else {
                continue;
            }

            count++;

            if (accNo >= nextAccountNumber) {
                nextAccountNumber = accNo + 1;
            }
        }

        file.close();
    }

    void saveTransaction(int accNo, string type, double amount) {
        ofstream file("transactions.txt", ios::app);

        if (!file) {
            cout << "Unable to save transaction!\n";
            return;
        }

        file << "Account: " << accNo
             << " | Type: " << type
             << " | Amount: " << amount << "\n";

        file.close();
    }
};

int main() {
    Bank bank;
    int choice;

    do {
        cout << "\n==============================";
        cout << "\n  BANKING MANAGEMENT SYSTEM";
        cout << "\n==============================";
        cout << "\n1. Create Account";
        cout << "\n2. Deposit Money";
        cout << "\n3. Withdraw Money";
        cout << "\n4. Display One Account";
        cout << "\n5. Display All Accounts";
        cout << "\n0. Exit";
        cout << "\nEnter your choice: ";

        if (!(cin >> choice)) {
            cout << "Invalid input!\n";
            cin.clear();
            cin.ignore(10000, '\n');
            continue;
        }

        switch (choice) {
            case 1:
                bank.createAccount();
                break;

            case 2:
                bank.depositMoney();
                break;

            case 3:
                bank.withdrawMoney();
                break;

            case 4:
                bank.displayAccount();
                break;

            case 5:
                bank.displayAllAccounts();
                break;

            case 0:
                cout << "Thank you for using the Deepanshu's Banking System!\n";
                break;

            default:
                cout << "Invalid choice!\n";
        }

    } while (choice != 0);

    return 0;
}

